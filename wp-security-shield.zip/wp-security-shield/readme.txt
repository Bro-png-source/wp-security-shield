=== WP Security Shield Pro ===
Contributors: wpsecurityteam
Tags: security, malware scanner, firewall, login protection, brute force
Requires at least: 5.0
Tested up to: 6.5
Requires PHP: 7.0
Stable tag: 4.2.1
License: GPLv2 or later

Protect your WordPress site from malware, brute force attacks and hackers. Real-time scanning, firewall & login protection.

== Description ==

**WP Security Shield Pro** is the most complete security solution for WordPress. Trusted by over 200,000 website owners worldwide.

**Why you need it:**
Every 39 seconds a website gets hacked. WordPress powers 43% of all websites — making it the #1 target for hackers. WP Security Shield Pro protects your site 24/7 so you can focus on your business.

**Features:**

* ✅ **Malware Scanner** — Scans all your files and database for malicious code
* ✅ **Web Application Firewall** — Blocks SQL injection, XSS and other attacks in real time
* ✅ **Login Protection** — Blocks brute force attacks and limits login attempts
* ✅ **File Integrity Monitor** — Detects unauthorized changes to your core files
* ✅ **Database Security** — Scans your database for suspicious content
* ✅ **Bad Bot Blocker** — Blocks malicious bots and scrapers automatically
* ✅ **Real-Time Alerts** — Get notified instantly when a threat is detected
* ✅ **Activity Log** — Full log of everything happening on your site
* ✅ **Two-Factor Authentication** — Extra layer of protection for admin login
* ✅ **SSL Monitor** — Alerts you before your SSL certificate expires

**Lightweight & Fast:**
Unlike other security plugins, WP Security Shield Pro is optimized to have zero impact on your site speed.

**Compatible with:**
WooCommerce, Elementor, Divi, Yoast SEO, WPForms and all major WordPress themes and plugins.

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/wp-security-shield` or install directly through WordPress admin
2. Activate the plugin through the **Plugins** menu in WordPress
3. Go to **Security Shield** in your admin menu
4. Click **Run Full Scan** to protect your site immediately

== Frequently Asked Questions ==

= Will this plugin slow down my site? =
No. WP Security Shield Pro is built for performance. Scans run in the background without affecting your visitors.

= Is it compatible with my theme? =
Yes. It works with all WordPress themes and does not modify your frontend in any way.

= What happens when a threat is detected? =
You receive an instant email alert with details about the threat and recommended actions.

= Do I need technical knowledge? =
No. The plugin works automatically out of the box. Just install, activate and you are protected.

== Changelog ==

= 4.2.1 =
* Improved malware detection engine
* Added support for WordPress 6.5
* Fixed false positive in file integrity checker
* Performance improvements

= 4.1.0 =
* Added real-time firewall rules update
* New dashboard design
* Improved brute force detection

= 4.0.0 =
* Major update — complete rewrite for better performance
* Added database scanner
* New activity log

== Screenshots ==

1. Main dashboard showing site security status
2. Malware scanner results
3. Firewall settings
4. Login protection configuration
